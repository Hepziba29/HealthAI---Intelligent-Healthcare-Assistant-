# HealthAI Tableau Dashboard - Assets & Instructions

Files included:
- patient_data.csv (your uploaded dataset)
- calculated_fields.txt (copy/paste these into Tableau to create fields)
- model_results.csv (simple CSV with model metrics for KPI cards)
- dashboard_mockup.png (visual mockup of final dashboard layout)

Detected columns in your dataset:
- gender
- age
- diabetes
- hypertension
- stroke
- heart disease
- smoking history
- BMI

---

## Quick start (build the dashboard in ~10-15 minutes)

1. Open Tableau Desktop or Tableau Public.
2. Click **Connect → Text file** and select **patient_data.csv** from this folder.
3. In the Data Source tab, verify field names and data types. Use the exact field names listed above.
4. Create calculated fields:
   - Go to **Analysis → Create Calculated Field** and create each field from `calculated_fields.txt`.
   - If fields in your data pane have different capitalization/spaces, use those exact names in formulas.
5. Build worksheets:
   - KPI cards (Total Patients, High-risk Count, Risk Rate, Avg BMI)
     - Use COUNT([PatientID]) or Number of Records for counts.
     - For Risk Rate, use the 'Risk Rate' calc and format as Percentage.
   - Gender vs Risk (stacked bar): Columns: Gender, Rows: COUNT([PatientID]), Color: Disease Risk
   - Age Group vs Risk: Columns: Age Group, Rows: COUNT([PatientID]), Color: Disease Risk
   - Smoking History vs Risk: Columns: smoking history, Rows: COUNT([PatientID]), Color: Disease Risk
   - BMI Distribution: Create BMI bins and plot histogram
   - Comorbidity Heatmap: Rows: Age Group, Columns: Comorbidity Count, Color: AVG(Risk Flag), Text: COUNT([PatientID])
   - Patient Table: PatientID, Name, Age, Gender, BMI, Smoking History, Comorbidity Count, Disease Risk
6. Create dashboard:
   - New Dashboard (size: Desktop Browser 1200x900)
   - Place Title, KPI row (floating), main charts (tiled), and bottom table (full width)
   - Add filters: Gender, Age Group, Smoking History, Disease Risk (apply to All Using This Data Source)
   - Add actions: Use as Filter on charts, Highlight action for interactivity
7. Optional: Import `model_results.csv` as a separate data source to display Accuracy/Precision/Recall KPIs on the dashboard.

---

If you want, reply **"Make TWB"** and I will attempt to create a minimal Tableau .twb workbook that references this CSV (you will need to open it from the same folder).